<h2>
    <br>A következő címen és telefonon érhet el:<br>
    <br>Cím: ...<br>
    <br>Telefon: ...<br>
</h2>
